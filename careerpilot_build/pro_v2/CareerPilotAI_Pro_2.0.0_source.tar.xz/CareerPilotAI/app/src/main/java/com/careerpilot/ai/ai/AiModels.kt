package com.careerpilot.ai.ai


data class AiMessage(val role: String, val content: String)

enum class AiTaskType {
    FAST_EXTRACTION,
    JOB_CLASSIFICATION,
    WEB_RESEARCH,
    COMPLEX_REASONING,
    RESUME_WRITING,
    DOCUMENT_VISION,
    ATS_VALIDATION,
    TOOL_ORCHESTRATION,
    CODE_DIAGNOSTICS,
    COPILOT_CHAT
}

data class AiRequest(
    val taskType: AiTaskType,
    val messages: List<AiMessage>,
    val preferredModels: List<String> = emptyList(),
    val temperature: Double = 0.2,
    val maxTokens: Int = 2048,
    val requireJsonObject: Boolean = false,
    val deadlineEpochMs: Long = System.currentTimeMillis() + 180_000
)

data class AiResult(
    val content: String,
    val providerId: String,
    val modelId: String,
    val latencyMs: Long,
    val attempts: List<String>
)

sealed class AiFailure(message: String, cause: Throwable? = null) : Exception(message, cause) {
    class Unauthorized(message: String) : AiFailure(message)
    class RateLimited(message: String, val retryAfterMs: Long) : AiFailure(message)
    class ProviderUnavailable(message: String) : AiFailure(message)
    class InvalidResponse(message: String) : AiFailure(message)
    class Exhausted(message: String) : AiFailure(message)
}

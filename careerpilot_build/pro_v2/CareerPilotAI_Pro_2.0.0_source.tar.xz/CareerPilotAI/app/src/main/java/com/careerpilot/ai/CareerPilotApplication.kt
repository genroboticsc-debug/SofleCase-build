package com.careerpilot.ai

import android.app.Application
import com.careerpilot.ai.core.AppContainer

class CareerPilotApplication : Application() {
    val container: AppContainer by lazy { AppContainer(this) }

    override fun onCreate() {
        super.onCreate()
        container.initialize()
    }
}

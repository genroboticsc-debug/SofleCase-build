package com.careerpilot.ai.ai.protocol

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class ChatMessageDto(
    val role: String,
    val content: String
)

@Serializable
data class ChatCompletionRequestDto(
    val model: String,
    val messages: List<ChatMessageDto>,
    val temperature: Double = 0.2,
    @SerialName("max_tokens") val maxTokens: Int = 2048,
    val stream: Boolean = false,
    @SerialName("response_format") val responseFormat: ResponseFormatDto? = null
)

@Serializable
data class ResponseFormatDto(val type: String = "json_object")

@Serializable
data class ChatCompletionResponseDto(
    val choices: List<ChoiceDto> = emptyList(),
    val usage: UsageDto? = null
)

@Serializable
data class ChoiceDto(val message: ChatMessageDto)

@Serializable
data class UsageDto(
    @SerialName("prompt_tokens") val promptTokens: Int? = null,
    @SerialName("completion_tokens") val completionTokens: Int? = null,
    @SerialName("total_tokens") val totalTokens: Int? = null
)

@Serializable
data class ErrorEnvelopeDto(val error: ErrorDto? = null)

@Serializable
data class ErrorDto(
    val message: String = "Unknown provider error",
    val type: String? = null,
    val code: String? = null
)

@echo off
setlocal
set ROOT_DIR=%~dp0
set GRADLE_VERSION=8.13
set BOOTSTRAP=%ROOT_DIR%.gradle-bootstrap
set DIST_DIR=%BOOTSTRAP%\gradle-%GRADLE_VERSION%
set ZIP_FILE=%BOOTSTRAP%\gradle-%GRADLE_VERSION%-bin.zip
set URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip
if not exist "%DIST_DIR%\bin\gradle.bat" (
  if not exist "%BOOTSTRAP%" mkdir "%BOOTSTRAP%"
  if not exist "%ZIP_FILE%" powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%URL%' -OutFile '%ZIP_FILE%'"
  if errorlevel 1 exit /b 1
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%ZIP_FILE%' -DestinationPath '%BOOTSTRAP%' -Force"
  if errorlevel 1 exit /b 1
)
call "%DIST_DIR%\bin\gradle.bat" %*
endlocal

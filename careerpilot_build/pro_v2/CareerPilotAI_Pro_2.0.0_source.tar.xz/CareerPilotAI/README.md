# CareerPilot AI — Android autonomous job-application scaffold

This repository is the first functional implementation checkpoint for a privately sideloaded Android app. It provides:

- NVIDIA NIM-first OpenAI-compatible API routing.
- Ordered model and provider fallback.
- Per-provider concurrency control, cooldowns, exponential backoff and circuit-breaking state.
- Encrypted API-key storage through Android Keystore AES-GCM.
- Room-backed jobs, workflow tasks, audit logs and Copilot messages.
- Foreground autonomous workflow service with Start, Pause and Stop controls.
- Resume/cover-letter generation gates that prohibit unsupported claims.
- Persistent application-pack generation through Android's Storage Access Framework.
- A modern Jetpack Compose interface for dashboard, jobs, automation, Copilot and settings.

## Current implementation boundary

This checkpoint is deliberately honest:

- It generates text application packs. Exact DOCX/PDF object-level editing is the next module and is not falsely represented as complete.
- It includes demo job records so the complete state machine can be exercised immediately.
- Live public job discovery is implemented for Greenhouse, Lever and Ashby company boards. Add board identifiers under **Settings → Live ATS sources**.
- General web-search aggregation, browser form automation, OAuth email and CAPTCHA/user-intervention flows remain later checkpoints.
- A free endpoint can still impose a hard quota or outage. The router preserves work, changes route and retries; it cannot create unlimited capacity.

## Toolchain

- Android Gradle Plugin 8.13.2
- Gradle 8.13
- Kotlin 2.3.21
- compileSdk / targetSdk 36
- Jetpack Compose BOM 2026.06.00
- Room 2.8.4
- WorkManager 2.11.2

## Open in Android Studio

1. Install a recent Android Studio release supporting AGP 8.13.
2. Install Android SDK Platform 36 and Build Tools 35.0.0 or newer.
3. Open this folder and allow Gradle sync.
4. In **Settings → AI providers**, enable NVIDIA NIM and add your NVIDIA API key.
5. Choose an application-pack folder.
6. Press **Start** in Automation.

The NVIDIA endpoint is configured as:

```text
https://integrate.api.nvidia.com/v1/chat/completions
```

Default model candidates are editable in the `providers` database seed:

```text
nvidia/nemotron-3-super-120b-a12b
moonshotai/kimi-k2.6
deepseek-ai/deepseek-v4-flash
z-ai/glm5.1
```

Model availability can change. The next checkpoint will add automatic `/models` discovery where supported and a catalogue refresh adapter for NVIDIA.

## Build

```bash
./gradlew assembleDebug
```

The debug APK will be generated at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Security

- API keys are encrypted with a non-exportable Android Keystore key.
- Authorization headers are redacted from OkHttp logging.
- HTTP cleartext traffic is disabled.
- Candidate claims are constrained to the saved evidence profile.
- The app does not bypass CAPTCHA, OTP, access controls or provider quotas.

## Next implementation checkpoint

1. Search connectors: Tavily, Brave, Serper and configurable web extraction.
2. SmartRecruiters, Workable, Recruitee and Personio public-feed connectors.
3. Immutable base-resume import and OOXML-preserving DOCX editor.
4. PDF object inspection and exact text-object replacement only when exact geometry/font data exists.
5. Assisted browser application engine with explicit user gates for declarations, CAPTCHA and OTP.
6. Gmail OAuth drafts and application tracking.
7. Provider model discovery and task-specific benchmark telemetry.

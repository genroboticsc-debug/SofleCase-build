from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


def run(command: list[str]) -> None:
    print("+", " ".join(command), flush=True)
    subprocess.run(command, check=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    root = args.root.resolve()
    source = root / "scripts" / "dilemma_3x5_3_top.py"
    reference = root / "reference" / "top.stl"
    generated = root / "generated"
    reports = root / "reports"
    reports.mkdir(parents=True, exist_ok=True)

    run([
        sys.executable, str(root / "validation" / "strict_srot_audit.py"),
        "--source", str(source), "--reference", str(reference),
        "--report", str(reports / "strict_srot_audit.json"),
    ])
    run([sys.executable, str(source), "--output-dir", str(generated)])
    run([
        sys.executable, str(root / "validation" / "validate_true_boolean.py"),
        "--reference-stl", str(reference),
        "--generated-step", str(generated / "dilemma_3x5_3_top.step"),
        "--generated-stl", str(generated / "dilemma_3x5_3_top.stl"),
        "--report", str(reports / "true_boolean_validation.json"),
    ])
    summary = {
        "strict_srot": json.loads((reports / "strict_srot_audit.json").read_text()),
        "true_boolean": json.loads((reports / "true_boolean_validation.json").read_text()),
    }
    summary["overall_status"] = (
        "PASS" if summary["strict_srot"]["overall_status"] == "PASS"
        and summary["true_boolean"]["overall_status"] == "PASS" else "FAIL"
    )
    (reports / "final_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
    return 0 if summary["overall_status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path
from typing import Any

EXPECTED_REFERENCE_SHA256 = "734e7c741510f7062f89e2e7a72ed0f6afa1aefa92f5cba7207be638ef9c4eb8"
ALLOWED_IMPORT_ROOTS = {"__future__", "argparse", "dataclasses", "math", "pathlib", "build123d"}
FORBIDDEN_IMPORT_ROOTS = {
    "OCP", "cadquery", "trimesh", "numpy", "scipy", "shapely", "meshio",
    "pickle", "base64", "subprocess", "marshal", "zlib", "gzip", "bz2", "lzma",
}
FORBIDDEN_CALL_NAMES = {
    "eval", "exec", "compile", "open", "__import__", "import_step", "import_stl",
    "read", "loads", "load", "from_stl", "from_step",
}
FORBIDDEN_ATTRIBUTE_CALLS = {
    "read_text", "read_bytes", "read", "loads", "load", "decode", "decompress",
    "run", "Popen", "system", "check_call", "check_output",
}
REQUIRED_FUNCTIONS = {
    "create_outer_perimeter", "_support_stage", "_controller_transition_strip",
    "_replace_middle_controller_returns", "create_top_case", "export_candidate", "main",
}
REQUIRED_CONSTRUCTORS = {
    "Edge.make_line", "Edge.make_bezier", "Edge.make_three_point_arc",
    "Wire.make_polygon", "Solid.extrude",
}
REQUIRED_FEATURE_OPERATIONS = {"fuse", "cut", "offset_2d"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def dotted_name(node: ast.AST) -> str:
    parts: list[str] = []
    current: ast.AST | None = node
    while isinstance(current, ast.Attribute):
        parts.append(current.attr)
        current = current.value
    if isinstance(current, ast.Name):
        parts.append(current.id)
    return ".".join(reversed(parts))


def audit(source_path: Path, reference_path: Path | None = None) -> dict[str, Any]:
    source = source_path.read_text(encoding="utf-8")
    tree = ast.parse(source, filename=str(source_path))

    imports: list[str] = []
    forbidden_imports: list[str] = []
    function_names: set[str] = set()
    constructor_calls: set[str] = set()
    operation_calls: set[str] = set()
    forbidden_calls: list[dict[str, Any]] = []
    string_literals: list[str] = []

    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            function_names.add(node.name)
        elif isinstance(node, ast.Import):
            for alias in node.names:
                root = alias.name.split(".", 1)[0]
                imports.append(alias.name)
                if root not in ALLOWED_IMPORT_ROOTS or root in FORBIDDEN_IMPORT_ROOTS:
                    forbidden_imports.append(alias.name)
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ""
            root = module.split(".", 1)[0]
            imports.append(module)
            if root not in ALLOWED_IMPORT_ROOTS or root in FORBIDDEN_IMPORT_ROOTS:
                forbidden_imports.append(module)
        elif isinstance(node, ast.Call):
            name = dotted_name(node.func)
            base = name.rsplit(".", 1)[-1]
            if name in REQUIRED_CONSTRUCTORS:
                constructor_calls.add(name)
            if base in REQUIRED_FEATURE_OPERATIONS:
                operation_calls.add(base)
            if base in FORBIDDEN_CALL_NAMES or base in FORBIDDEN_ATTRIBUTE_CALLS:
                forbidden_calls.append({"line": node.lineno, "call": name})
        elif isinstance(node, ast.Constant) and isinstance(node.value, str):
            string_literals.append(node.value)

    missing_functions = sorted(REQUIRED_FUNCTIONS - function_names)
    missing_constructors = sorted(REQUIRED_CONSTRUCTORS - constructor_calls)
    missing_operations = sorted(REQUIRED_FEATURE_OPERATIONS - operation_calls)

    source_lower = source.lower()
    textual_forbidden = sorted(
        token for token in (
            ".stl", ".step", ".brep", "reference_unique", "mesh replay",
            "triangle replay", "b-rep replay", "brep replay", "cached brep",
        )
        if token in source_lower
    )
    # Export file suffixes are permitted only where files are written. Any input/read API
    # is separately forbidden above, so suffix literals alone do not constitute replay.
    textual_forbidden = [item for item in textual_forbidden if item not in {".stl", ".step"}]

    reference_hash = sha256(reference_path) if reference_path and reference_path.exists() else None
    reference_identity_ok = reference_hash in {None, EXPECTED_REFERENCE_SHA256}

    checks = {
        "syntax_parse": True,
        "allowed_imports_only": not forbidden_imports,
        "no_reference_or_binary_read_calls": not forbidden_calls,
        "no_replay_markers": not textual_forbidden,
        "required_feature_functions_present": not missing_functions,
        "required_native_constructors_present": not missing_constructors,
        "required_boolean_and_offset_operations_present": not missing_operations,
        "reference_identity": reference_identity_ok,
        "standalone_entry_guard": 'if __name__ == "__main__"' in source,
        "single_source_file_no_local_geometry_imports": all(
            root in ALLOWED_IMPORT_ROOTS for root in {item.split(".", 1)[0] for item in imports}
        ),
    }
    overall = all(checks.values())
    return {
        "audit": "STRICT_SROT_STATIC_SOURCE_AUDIT_V1",
        "source": str(source_path.resolve()),
        "source_sha256": sha256(source_path),
        "reference": str(reference_path.resolve()) if reference_path else None,
        "reference_sha256": reference_hash,
        "expected_reference_sha256": EXPECTED_REFERENCE_SHA256,
        "classification": "GENUINE_ANALYTIC_PARAMETRIC_FEATURE_TREE" if overall else "REJECTED",
        "overall_status": "PASS" if overall else "FAIL",
        "checks": checks,
        "evidence": {
            "imports": sorted(set(imports)),
            "native_constructor_calls": sorted(constructor_calls),
            "feature_operations": sorted(operation_calls),
            "defined_functions": sorted(function_names),
            "forbidden_imports": forbidden_imports,
            "forbidden_calls": forbidden_calls,
            "forbidden_replay_markers": textual_forbidden,
            "missing_functions": missing_functions,
            "missing_constructors": missing_constructors,
            "missing_operations": missing_operations,
        },
        "scope_note": (
            "This is a source-purity and feature-tree audit. It does not certify B-Rep "
            "generation, topology, STEP/STL export, or numeric Boolean equivalence."
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--reference", type=Path)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    result = audit(args.source, args.reference)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if result["overall_status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Any

EXPECTED_REFERENCE_SHA256 = "734e7c741510f7062f89e2e7a72ed0f6afa1aefa92f5cba7207be638ef9c4eb8"
THRESHOLDS_PERCENT = {
    "symmetric_difference": 0.01,
    "volume": 0.1,
    "surface_area": 0.1,
    "center_of_mass_bbox_diagonal": 0.1,
    "step_stl_symmetric_difference": 0.01,
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _imports() -> dict[str, Any]:
    try:
        import OCP
        from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
        from OCP.BRepBndLib import BRepBndLib
        from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeSolid, BRepBuilderAPI_Sewing
        from OCP.BRepCheck import BRepCheck_Analyzer
        from OCP.BRepGProp import BRepGProp
        from OCP.Bnd import Bnd_Box
        from OCP.GProp import GProp_GProps
        from OCP.IFSelect import IFSelect_RetDone
        from OCP.STEPControl import STEPControl_Reader
        from OCP.StlAPI import StlAPI_Reader
        from OCP.TopAbs import TopAbs_FACE, TopAbs_SHELL, TopAbs_SOLID
        from OCP.TopExp import TopExp_Explorer
        from OCP.TopoDS import TopoDS, TopoDS_Shape
    except Exception as exc:
        raise RuntimeError(
            "Pinned OpenCascade runtime is unavailable. Install cadquery-ocp==7.9.3.1.1 "
            "and rerun; no fallback Boolean engine is permitted."
        ) from exc
    return locals()


def count_subshapes(shape: Any, kind: Any, api: dict[str, Any]) -> int:
    explorer = api["TopExp_Explorer"](shape, kind)
    count = 0
    while explorer.More():
        count += 1
        explorer.Next()
    return count


def stl_to_exact_triangle_solid(path: Path, api: dict[str, Any], sewing_tolerance: float = 1.0e-7) -> Any:
    shape = api["TopoDS_Shape"]()
    reader = api["StlAPI_Reader"]()
    if not reader.Read(shape, str(path)):
        raise RuntimeError(f"Failed to read STL: {path}")
    sewing = api["BRepBuilderAPI_Sewing"](sewing_tolerance)
    face_explorer = api["TopExp_Explorer"](shape, api["TopAbs_FACE"])
    face_count = 0
    while face_explorer.More():
        sewing.Add(face_explorer.Current())
        face_count += 1
        face_explorer.Next()
    if face_count == 0:
        raise RuntimeError(f"STL contains no faces: {path}")
    sewing.Perform()
    sewn = sewing.SewedShape()
    shell_explorer = api["TopExp_Explorer"](sewn, api["TopAbs_SHELL"])
    shells: list[Any] = []
    while shell_explorer.More():
        shells.append(api["TopoDS"].Shell_s(shell_explorer.Current()))
        shell_explorer.Next()
    if len(shells) != 1:
        raise RuntimeError(f"Expected one sewn shell from {path}, got {len(shells)}")
    maker = api["BRepBuilderAPI_MakeSolid"](shells[0])
    if not maker.IsDone():
        raise RuntimeError(f"Could not make one solid from {path}")
    solid = maker.Solid()
    props = api["GProp_GProps"]()
    api["BRepGProp"].VolumeProperties_s(solid, props)
    if props.Mass() < 0:
        solid.Reverse()
    if not api["BRepCheck_Analyzer"](solid).IsValid():
        raise RuntimeError(f"Triangle B-Rep is invalid: {path}")
    return solid


def load_step(path: Path, api: dict[str, Any]) -> Any:
    reader = api["STEPControl_Reader"]()
    status = reader.ReadFile(str(path))
    if status != api["IFSelect_RetDone"]:
        raise RuntimeError(f"Failed to read STEP: {path}; status={status}")
    transferred = reader.TransferRoots()
    if transferred <= 0:
        raise RuntimeError(f"STEP transferred no roots: {path}")
    shape = reader.OneShape()
    solid_count = count_subshapes(shape, api["TopAbs_SOLID"], api)
    if solid_count != 1:
        raise RuntimeError(f"Expected exactly one STEP solid, got {solid_count}: {path}")
    if not api["BRepCheck_Analyzer"](shape).IsValid():
        raise RuntimeError(f"STEP B-Rep is invalid: {path}")
    return shape


def properties(shape: Any, api: dict[str, Any]) -> dict[str, Any]:
    volume_props = api["GProp_GProps"]()
    surface_props = api["GProp_GProps"]()
    api["BRepGProp"].VolumeProperties_s(shape, volume_props)
    api["BRepGProp"].SurfaceProperties_s(shape, surface_props)
    center = volume_props.CentreOfMass()
    box = api["Bnd_Box"]()
    api["BRepBndLib"].Add_s(shape, box)
    xmin, ymin, zmin, xmax, ymax, zmax = [float(value) for value in box.Get()]
    extents = [xmax - xmin, ymax - ymin, zmax - zmin]
    return {
        "volume_mm3": abs(float(volume_props.Mass())),
        "surface_area_mm2": float(surface_props.Mass()),
        "center_of_mass_mm": [float(center.X()), float(center.Y()), float(center.Z())],
        "bbox_min_mm": [xmin, ymin, zmin],
        "bbox_max_mm": [xmax, ymax, zmax],
        "bbox_extents_mm": extents,
        "bbox_diagonal_mm": math.sqrt(sum(value * value for value in extents)),
        "solid_count": count_subshapes(shape, api["TopAbs_SOLID"], api),
        "valid_brep": bool(api["BRepCheck_Analyzer"](shape).IsValid()),
    }


def difference_volume(argument: Any, tool: Any, label: str, api: dict[str, Any]) -> float:
    operation = api["BRepAlgoAPI_Cut"](argument, tool)
    operation.SetRunParallel(False)
    operation.Build()
    if not operation.IsDone():
        raise RuntimeError(f"Exact OpenCascade subtraction failed: {label}")
    result = operation.Shape()
    if result.IsNull():
        return 0.0
    if not api["BRepCheck_Analyzer"](result).IsValid():
        raise RuntimeError(f"Exact OpenCascade subtraction produced invalid B-Rep: {label}")
    props = api["GProp_GProps"]()
    api["BRepGProp"].VolumeProperties_s(result, props)
    return abs(float(props.Mass()))


def compare(reference: Any, generated: Any, api: dict[str, Any]) -> dict[str, Any]:
    ref = properties(reference, api)
    gen = properties(generated, api)
    ref_minus_gen = difference_volume(reference, generated, "reference-generated", api)
    gen_minus_ref = difference_volume(generated, reference, "generated-reference", api)
    symmetric = ref_minus_gen + gen_minus_ref
    volume_error = 100.0 * abs(gen["volume_mm3"] - ref["volume_mm3"]) / ref["volume_mm3"]
    area_error = 100.0 * abs(gen["surface_area_mm2"] - ref["surface_area_mm2"]) / ref["surface_area_mm2"]
    delta = [gen["center_of_mass_mm"][i] - ref["center_of_mass_mm"][i] for i in range(3)]
    com_shift = math.sqrt(sum(value * value for value in delta))
    com_percent = 100.0 * com_shift / ref["bbox_diagonal_mm"]
    sym_percent = 100.0 * symmetric / ref["volume_mm3"]
    bbox_abs = [abs(gen["bbox_extents_mm"][i] - ref["bbox_extents_mm"][i]) for i in range(3)]
    passes = {
        "topology": gen["valid_brep"] and gen["solid_count"] == 1,
        "symmetric_difference": sym_percent < THRESHOLDS_PERCENT["symmetric_difference"],
        "volume": volume_error < THRESHOLDS_PERCENT["volume"],
        "surface_area": area_error < THRESHOLDS_PERCENT["surface_area"],
        "center_of_mass": com_percent < THRESHOLDS_PERCENT["center_of_mass_bbox_diagonal"],
    }
    return {
        "reference": ref,
        "generated": gen,
        "differences": {
            "reference_minus_generated_mm3": ref_minus_gen,
            "generated_minus_reference_mm3": gen_minus_ref,
            "symmetric_difference_mm3": symmetric,
            "symmetric_difference_percent": sym_percent,
            "volume_difference_percent": volume_error,
            "surface_area_difference_percent": area_error,
            "center_of_mass_delta_mm": delta,
            "center_of_mass_shift_mm": com_shift,
            "center_of_mass_shift_percent_of_reference_bbox_diagonal": com_percent,
            "bbox_extent_abs_difference_mm": bbox_abs,
        },
        "passes": passes,
        "pass": all(passes.values()),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reference-stl", type=Path, required=True)
    parser.add_argument("--generated-step", type=Path, required=True)
    parser.add_argument("--generated-stl", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()

    if sha256(args.reference_stl) != EXPECTED_REFERENCE_SHA256:
        raise RuntimeError("Reference SHA-256 mismatch; refusing to validate a different geometry")
    api = _imports()
    reference = stl_to_exact_triangle_solid(args.reference_stl, api)
    generated_step = load_step(args.generated_step, api)
    generated_stl = stl_to_exact_triangle_solid(args.generated_stl, api)

    primary = compare(reference, generated_step, api)
    step_stl = compare(generated_step, generated_stl, api)
    step_stl_pass = (
        step_stl["differences"]["symmetric_difference_percent"]
        < THRESHOLDS_PERCENT["step_stl_symmetric_difference"]
        and step_stl["passes"]["topology"]
    )
    result = {
        "validator": "STRICT_TRUE_BOOLEAN_VALIDATOR_V1",
        "boolean_engine": "OpenCascade BRepAlgoAPI_Cut, exact mode, fuzzy tolerance 0.0",
        "fallback_used": False,
        "reference_sha256": sha256(args.reference_stl),
        "generated_step_sha256": sha256(args.generated_step),
        "generated_stl_sha256": sha256(args.generated_stl),
        "thresholds_percent": THRESHOLDS_PERCENT,
        "reference_vs_generated_step": primary,
        "generated_step_vs_generated_stl": step_stl,
        "step_stl_congruence_pass": step_stl_pass,
        "overall_status": "PASS" if primary["pass"] and step_stl_pass else "FAIL",
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if result["overall_status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
